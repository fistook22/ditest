from flask import Blueprint

market = Blueprint('market', __name__, url_prefix='/market')